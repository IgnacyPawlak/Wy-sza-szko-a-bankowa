﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace operacje_na_plikach
{
    class Program
    {
        static void Main(string[] args)
        {
            DirectoryInfo wsbDir = new DirectoryInfo(".");
            Console.WriteLine(wsbDir.FullName);
            DirectoryInfo studentDir = new DirectoryInfo(@"C:\Users\Student");
            //DirectoryInfo studentDir = new DirectoryInfo("C:\\Users\\Student\\Dekstop");
            Console.WriteLine(studentDir.FullName);
            Console.WriteLine(studentDir.Name);
            Console.WriteLine(studentDir.Parent);
            Console.WriteLine(studentDir.Attributes);
            Console.WriteLine(studentDir.CreationTime);

            DirectoryInfo dataDir = new DirectoryInfo(@"C:\Users\Student\c#files");

            string[] clients = {
                "Agnieszka Nowak",
            "Grzegorz Brzęczyszczykiewicz",
            "Konstant Niebiański"
            };



            //tworzenie katalogu jeżeli nie isnieje

            string path = @"C:\Users\student\c#files";
            try
            {
                if (Directory.Exists(@"C:\Users\Student\c#files"))
                {
                    Console.WriteLine("Katalog istnieje");
                }
                else
                {
                    Directory.CreateDirectory(@"C:\Users\Student\c#files");
                    string textFilePath = @"C:\Users\Student\c#files\textFile1.txt";
                    File.WriteAllLines(textFilePath, clients);
                    Console.WriteLine("\nUtworzono katalof: {0}", Directory.GetCreationTime(path));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Błąd: {0}", e.Message);
            }
            try
            {
                Console.WriteLine("czy chcesz usunąć katalog? 1 -tak 0 -nie");

                int choice = int.Parse(Console.ReadLine());
                if (choice == 1)
                {
                    Directory.Delete(@"C:\Users\Student\c#files", true);
                    if (Directory.Exists(@"C:\Users\Student\c#files"))
                    {
                        Console.WriteLine("Plik nie został usunięty");
                    }
                    else
                        Console.WriteLine("plik został usunięty");
                }
                else if (choice == 0)
                {
                    Console.WriteLine("Plik nie został usunięty");
                }
                else
                    Console.WriteLine("Złe dane");
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message);
            }

            Console.ReadKey();
        }
    }
}
